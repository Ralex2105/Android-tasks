package com.example.lab3_3

const val toFirst = R.id.bnToFirst
const val toSecond = R.id.bnToSecond
const val toThird = R.id.bnToThird
const val fragment1 = R.id.activity_main
const val fragment2 = R.id.fragment2
const val fragment3 = R.id.fragment3
